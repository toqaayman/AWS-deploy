(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./1fcq78hk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.entry.js",
		"common",
		94
	],
	"./1fcq78hk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/1fcq78hk.sc.entry.js",
		"common",
		95
	],
	"./2i50w2lv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.entry.js",
		"common",
		96
	],
	"./2i50w2lv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/2i50w2lv.sc.entry.js",
		"common",
		97
	],
	"./39fhulxe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.entry.js",
		"common",
		98
	],
	"./39fhulxe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/39fhulxe.sc.entry.js",
		"common",
		99
	],
	"./3hbcnxuc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.entry.js",
		"common",
		50
	],
	"./3hbcnxuc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hbcnxuc.sc.entry.js",
		"common",
		51
	],
	"./3pkkvczk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.entry.js",
		0,
		"common",
		120
	],
	"./3pkkvczk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3pkkvczk.sc.entry.js",
		0,
		"common",
		121
	],
	"./48sex9p5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/48sex9p5.entry.js",
		52
	],
	"./48sex9p5.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/48sex9p5.sc.entry.js",
		53
	],
	"./5klmpbas.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5klmpbas.entry.js",
		1,
		122
	],
	"./5klmpbas.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5klmpbas.sc.entry.js",
		1,
		123
	],
	"./5zcdwzsx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.entry.js",
		2
	],
	"./5zcdwzsx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5zcdwzsx.sc.entry.js",
		3
	],
	"./6kgso7pq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.entry.js",
		4
	],
	"./6kgso7pq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6kgso7pq.sc.entry.js",
		5
	],
	"./7hlpr3fd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.entry.js",
		0,
		"common",
		124
	],
	"./7hlpr3fd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/7hlpr3fd.sc.entry.js",
		0,
		"common",
		125
	],
	"./91yswq9n.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/91yswq9n.entry.js",
		54
	],
	"./91yswq9n.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/91yswq9n.sc.entry.js",
		55
	],
	"./admmxern.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.entry.js",
		56
	],
	"./admmxern.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/admmxern.sc.entry.js",
		57
	],
	"./ak14tg4e.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ak14tg4e.entry.js",
		58
	],
	"./ak14tg4e.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ak14tg4e.sc.entry.js",
		59
	],
	"./azzrjyyu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.entry.js",
		0,
		126
	],
	"./azzrjyyu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/azzrjyyu.sc.entry.js",
		0,
		127
	],
	"./b65tzyas.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.entry.js",
		"common",
		6
	],
	"./b65tzyas.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b65tzyas.sc.entry.js",
		"common",
		7
	],
	"./b7geaofq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b7geaofq.entry.js",
		60
	],
	"./b7geaofq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/b7geaofq.sc.entry.js",
		61
	],
	"./bb7q7tld.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.entry.js",
		"common",
		100
	],
	"./bb7q7tld.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bb7q7tld.sc.entry.js",
		"common",
		101
	],
	"./bheoje2y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bheoje2y.entry.js",
		8
	],
	"./bheoje2y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bheoje2y.sc.entry.js",
		9
	],
	"./d1xzdckz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d1xzdckz.entry.js",
		10
	],
	"./d1xzdckz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/d1xzdckz.sc.entry.js",
		11
	],
	"./devt5yhg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.entry.js",
		0,
		"common",
		128
	],
	"./devt5yhg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/devt5yhg.sc.entry.js",
		0,
		"common",
		129
	],
	"./djkq5plb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.entry.js",
		62
	],
	"./djkq5plb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/djkq5plb.sc.entry.js",
		63
	],
	"./eem8jsfz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eem8jsfz.entry.js",
		12
	],
	"./eem8jsfz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eem8jsfz.sc.entry.js",
		13
	],
	"./eghwkqif.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.entry.js",
		14
	],
	"./eghwkqif.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/eghwkqif.sc.entry.js",
		15
	],
	"./ek05jvfc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.entry.js",
		16
	],
	"./ek05jvfc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ek05jvfc.sc.entry.js",
		17
	],
	"./f5r41bls.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f5r41bls.entry.js",
		0,
		"common",
		102
	],
	"./f5r41bls.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/f5r41bls.sc.entry.js",
		0,
		"common",
		103
	],
	"./fkzdmlip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.entry.js",
		130
	],
	"./fkzdmlip.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fkzdmlip.sc.entry.js",
		131
	],
	"./fmzmhk3d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.entry.js",
		64
	],
	"./fmzmhk3d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fmzmhk3d.sc.entry.js",
		65
	],
	"./foblon1x.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/foblon1x.entry.js",
		"common",
		18
	],
	"./foblon1x.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/foblon1x.sc.entry.js",
		"common",
		19
	],
	"./hds9xywu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hds9xywu.entry.js",
		106
	],
	"./hds9xywu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/hds9xywu.sc.entry.js",
		107
	],
	"./helxzsef.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.entry.js",
		132
	],
	"./helxzsef.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/helxzsef.sc.entry.js",
		133
	],
	"./i5bu78vq.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.entry.js",
		66
	],
	"./i5bu78vq.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i5bu78vq.sc.entry.js",
		67
	],
	"./imcdx1xe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.entry.js",
		"common",
		108
	],
	"./imcdx1xe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/imcdx1xe.sc.entry.js",
		"common",
		109
	],
	"./iqlhkurd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.entry.js",
		68
	],
	"./iqlhkurd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iqlhkurd.sc.entry.js",
		69
	],
	"./isuxxasv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.entry.js",
		70
	],
	"./isuxxasv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/isuxxasv.sc.entry.js",
		71
	],
	"./iwgahuhw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.entry.js",
		20
	],
	"./iwgahuhw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/iwgahuhw.sc.entry.js",
		21
	],
	"./j20d1ikn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.entry.js",
		72
	],
	"./j20d1ikn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/j20d1ikn.sc.entry.js",
		73
	],
	"./jyhraxns.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyhraxns.entry.js",
		90
	],
	"./jyhraxns.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyhraxns.sc.entry.js",
		91
	],
	"./jzwyowjw.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.entry.js",
		22
	],
	"./jzwyowjw.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzwyowjw.sc.entry.js",
		23
	],
	"./k6eoch7h.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.entry.js",
		0,
		"common",
		134
	],
	"./k6eoch7h.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k6eoch7h.sc.entry.js",
		0,
		"common",
		135
	],
	"./kawnb1ql.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kawnb1ql.entry.js",
		74
	],
	"./kawnb1ql.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kawnb1ql.sc.entry.js",
		75
	],
	"./kgjnfunx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.entry.js",
		24
	],
	"./kgjnfunx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/kgjnfunx.sc.entry.js",
		25
	],
	"./lb8tayd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.entry.js",
		"common",
		110
	],
	"./lb8tayd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lb8tayd0.sc.entry.js",
		"common",
		111
	],
	"./llyqw4no.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.entry.js",
		76
	],
	"./llyqw4no.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/llyqw4no.sc.entry.js",
		77
	],
	"./mf2ayo12.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.entry.js",
		26
	],
	"./mf2ayo12.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mf2ayo12.sc.entry.js",
		27
	],
	"./mo7qeek2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.entry.js",
		"common",
		112
	],
	"./mo7qeek2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mo7qeek2.sc.entry.js",
		"common",
		113
	],
	"./mri9bdlj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.entry.js",
		136
	],
	"./mri9bdlj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mri9bdlj.sc.entry.js",
		137
	],
	"./mrs0ks1r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.entry.js",
		0,
		"common",
		138
	],
	"./mrs0ks1r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mrs0ks1r.sc.entry.js",
		0,
		"common",
		139
	],
	"./n1gqnu4m.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n1gqnu4m.entry.js",
		78
	],
	"./n1gqnu4m.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n1gqnu4m.sc.entry.js",
		79
	],
	"./n60sde1b.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n60sde1b.entry.js",
		28
	],
	"./n60sde1b.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n60sde1b.sc.entry.js",
		29
	],
	"./oc7j8k7y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.entry.js",
		"common",
		114
	],
	"./oc7j8k7y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oc7j8k7y.sc.entry.js",
		"common",
		115
	],
	"./oiucdv63.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiucdv63.entry.js",
		80
	],
	"./oiucdv63.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oiucdv63.sc.entry.js",
		81
	],
	"./pd9wflli.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.entry.js",
		"common",
		92
	],
	"./pd9wflli.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/pd9wflli.sc.entry.js",
		"common",
		93
	],
	"./qzdsdbvt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qzdsdbvt.entry.js",
		82
	],
	"./qzdsdbvt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qzdsdbvt.sc.entry.js",
		83
	],
	"./r2tscfp8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r2tscfp8.entry.js",
		0,
		"common",
		104
	],
	"./r2tscfp8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r2tscfp8.sc.entry.js",
		0,
		"common",
		105
	],
	"./r8dtlwvb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.entry.js",
		0,
		"common",
		140
	],
	"./r8dtlwvb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8dtlwvb.sc.entry.js",
		0,
		"common",
		141
	],
	"./r8g3twaz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8g3twaz.entry.js",
		"common",
		30
	],
	"./r8g3twaz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/r8g3twaz.sc.entry.js",
		"common",
		31
	],
	"./rkecsmgc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.entry.js",
		116
	],
	"./rkecsmgc.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rkecsmgc.sc.entry.js",
		117
	],
	"./ro1otaal.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ro1otaal.entry.js",
		1,
		142
	],
	"./ro1otaal.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ro1otaal.sc.entry.js",
		1,
		143
	],
	"./rrpxfm2a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.entry.js",
		144
	],
	"./rrpxfm2a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/rrpxfm2a.sc.entry.js",
		145
	],
	"./senscofp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.entry.js",
		32
	],
	"./senscofp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/senscofp.sc.entry.js",
		33
	],
	"./tg9wqmdk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tg9wqmdk.entry.js",
		0,
		"common",
		146
	],
	"./tg9wqmdk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tg9wqmdk.sc.entry.js",
		0,
		"common",
		147
	],
	"./tlbladaf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.entry.js",
		34
	],
	"./tlbladaf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tlbladaf.sc.entry.js",
		35
	],
	"./tn7df4wj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.entry.js",
		"common",
		118
	],
	"./tn7df4wj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tn7df4wj.sc.entry.js",
		"common",
		119
	],
	"./ugd3sahs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugd3sahs.entry.js",
		84
	],
	"./ugd3sahs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugd3sahs.sc.entry.js",
		85
	],
	"./uhyavx6a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.entry.js",
		0,
		148
	],
	"./uhyavx6a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uhyavx6a.sc.entry.js",
		0,
		149
	],
	"./upnvzchf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upnvzchf.entry.js",
		36
	],
	"./upnvzchf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/upnvzchf.sc.entry.js",
		37
	],
	"./urrnn8ys.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/urrnn8ys.entry.js",
		"common",
		38
	],
	"./urrnn8ys.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/urrnn8ys.sc.entry.js",
		"common",
		39
	],
	"./vompwuhi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.entry.js",
		40
	],
	"./vompwuhi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vompwuhi.sc.entry.js",
		41
	],
	"./vypdotd0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.entry.js",
		42
	],
	"./vypdotd0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vypdotd0.sc.entry.js",
		43
	],
	"./wb4mk1b9.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.entry.js",
		0,
		"common",
		150
	],
	"./wb4mk1b9.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wb4mk1b9.sc.entry.js",
		0,
		"common",
		151
	],
	"./wddurbsg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wddurbsg.entry.js",
		44
	],
	"./wddurbsg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wddurbsg.sc.entry.js",
		45
	],
	"./wjdsdnuu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.entry.js",
		86
	],
	"./wjdsdnuu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wjdsdnuu.sc.entry.js",
		87
	],
	"./wpufhrqd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpufhrqd.entry.js",
		"common",
		46
	],
	"./wpufhrqd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wpufhrqd.sc.entry.js",
		"common",
		47
	],
	"./wrpzmdqx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.entry.js",
		"common",
		48
	],
	"./wrpzmdqx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wrpzmdqx.sc.entry.js",
		"common",
		49
	],
	"./wwcmkxu8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wwcmkxu8.entry.js",
		0,
		"common",
		152
	],
	"./wwcmkxu8.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wwcmkxu8.sc.entry.js",
		0,
		"common",
		153
	],
	"./x5xnv4jv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.entry.js",
		0,
		"common",
		154
	],
	"./x5xnv4jv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/x5xnv4jv.sc.entry.js",
		0,
		"common",
		155
	],
	"./xajhwvib.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.entry.js",
		88
	],
	"./xajhwvib.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xajhwvib.sc.entry.js",
		89
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\r\n  <ion-split-pane when=\"false\">\r\n    <ion-menu>\r\n      <ion-header>\r\n        <ion-toolbar>\r\n          <ion-title>Menu</ion-title>\r\n        </ion-toolbar>\r\n      </ion-header>\r\n      <ion-content>\r\n        <ion-list>\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\r\n            <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\r\n              <ion-icon slot=\"start\" [name]=\"p.icon\"></ion-icon>\r\n              <ion-label>\r\n                {{p.title}}\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n        </ion-list>\r\n      </ion-content>\r\n    </ion-menu>\r\n\r\n\r\n    <ion-content main>\r\n      <app-menubar></app-menubar>\r\n      <ion-router-outlet style=\"margin-top: 56px;\"></ion-router-outlet>\r\n    </ion-content>\r\n\r\n\r\n\r\n  </ion-split-pane>\r\n</ion-app>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-login/auth-login.component.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-login/auth-login.component.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<form [formGroup]=\"loginForm\" (submit)=\"onSubmit($event)\">\r\n  <ion-item>\r\n    <ion-label position=\"floating\" color=\"primary\">Email</ion-label>\r\n    <ion-input type=\"text\" formControlName=\"email\" required></ion-input>\r\n  </ion-item>\r\n  <ion-item>\r\n    <ion-label position=\"floating\" color=\"primary\">Password</ion-label>\r\n    <ion-input type=\"password\" formControlName=\"password\" required></ion-input>\r\n  </ion-item>\r\n  <ion-button \r\n    color=\"primary\" \r\n    type=\"submit\"\r\n    [disabled]=\"!loginForm.valid\">\r\n    Log In\r\n  </ion-button>\r\n  {{error}}\r\n</form>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-menu-button/auth-menu-button.component.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-menu-button/auth-menu-button.component.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- display login and register buttons if user is logged in -->\r\n<ion-item-group\r\n  *ngIf=\" !( auth.currentUser$ | async ) \">\r\n    <ion-button \r\n    color=\"secondary\" \r\n    (click)=\"presentRegister()\">\r\n      Register\r\n    </ion-button>\r\n    <ion-button \r\n    (click)=\"presentLogin()\"\r\n    color=\"primary\">\r\n     Log In\r\n    </ion-button>\r\n</ion-item-group>\r\n\r\n<!-- display the avatar if user is logged in -->\r\n<ion-item-group\r\n  *ngIf=\" ( auth.currentUser$ | async ) \">\r\n  <ion-button \r\n  color=\"secondary\">\r\n    {{( auth.currentUser$ | async ).email }}\r\n  </ion-button>\r\n  <ion-button \r\n  (click)=\"logout()\"\r\n  color=\"primary\">\r\n    Log Out\r\n  </ion-button>\r\n</ion-item-group>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.html":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-button color=\"secondary\" (click)=\"dismissModal()\">Dismiss</ion-button>\r\n\r\n<p>\r\n  auth-menu-user works!\r\n</p>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-register/auth-register.component.html":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-register/auth-register.component.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<form [formGroup]=\"registerForm\" (submit)=\"onSubmit($event)\">\r\n    <ion-item>\r\n      <ion-label position=\"floating\" color=\"primary\">Name</ion-label>\r\n      <ion-input type=\"text\" formControlName=\"name\" required></ion-input>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label position=\"floating\" color=\"primary\">Email</ion-label>\r\n      <ion-input type=\"text\" formControlName=\"email\" required></ion-input>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label position=\"floating\" color=\"primary\">Password</ion-label>\r\n      <ion-input type=\"password\" formControlName=\"password\" required></ion-input>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label position=\"floating\" color=\"primary\">Confirm Password</ion-label>\r\n      <ion-input type=\"password\" formControlName=\"password_confirm\" required></ion-input>\r\n    </ion-item>\r\n    <ion-button \r\n      color=\"primary\" \r\n      type=\"submit\"\r\n      [disabled]=\"!registerForm.valid \">\r\n      Register\r\n    </ion-button> {{error}}\r\n  </form>\r\n  ");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/menubar/menubar.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/menubar/menubar.component.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>\r\n      {{ appName }}\r\n    </ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <app-auth-menu-button></app-auth-menu-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>");

/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __exportStar(m, exports) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
    if (m) return m.call(o);
    return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}


/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home/home.module": [
		"./src/app/home/home.module.ts",
		"home-home-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/api/api.module.ts":
/*!***********************************!*\
  !*** ./src/app/api/api.module.ts ***!
  \***********************************/
/*! exports provided: ApiModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiModule", function() { return ApiModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");



var components = [];
var ApiModule = /** @class */ (function () {
    function ApiModule() {
    }
    ApiModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClientModule"],
            ],
            declarations: components,
            exports: components,
            providers: []
        })
    ], ApiModule);
    return ApiModule;
}());



/***/ }),

/***/ "./src/app/api/api.service.ts":
/*!************************************!*\
  !*** ./src/app/api/api.service.ts ***!
  \************************************/
/*! exports provided: ApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiService", function() { return ApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");





var API_HOST = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiHost;
var ApiService = /** @class */ (function () {
    function ApiService(http) {
        this.http = http;
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
        };
    }
    ApiService_1 = ApiService;
    ApiService.handleError = function (error) {
        alert(error.message);
    };
    ApiService.extractData = function (res) {
        var body = res;
        return body || {};
    };
    ApiService.prototype.setAuthToken = function (token) {
        this.httpOptions.headers = this.httpOptions.headers.append('Authorization', "jwt " + token);
        this.token = token;
    };
    ApiService.prototype.get = function (endpoint) {
        var url = "" + API_HOST + endpoint;
        var req = this.http.get(url, this.httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(ApiService_1.extractData));
        return req
            .toPromise()
            .catch(function (e) {
            ApiService_1.handleError(e);
            throw e;
        });
    };
    ApiService.prototype.post = function (endpoint, data) {
        var url = "" + API_HOST + endpoint;
        return this.http.post(url, data, this.httpOptions)
            .toPromise()
            .catch(function (e) {
            ApiService_1.handleError(e);
            throw e;
        });
    };
    ApiService.prototype.upload = function (endpoint, file, payload) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var signed_url, headers, req;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.get(endpoint + "/signed-url/" + file.name)];
                    case 1:
                        signed_url = (_a.sent()).url;
                        headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': file.type });
                        req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpRequest"]('PUT', signed_url, file, {
                            headers: headers,
                            reportProgress: true,
                        });
                        return [2 /*return*/, new Promise(function (resolve) {
                                _this.http.request(req).subscribe(function (resp) {
                                    if (resp && resp.status && resp.status === 200) {
                                        resolve(_this.post(endpoint, payload));
                                    }
                                });
                            })];
                }
            });
        });
    };
    var ApiService_1;
    ApiService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
    ]; };
    ApiService = ApiService_1 = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ApiService);
    return ApiService;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: './home/home.module#HomePageModule'
    }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.appPages = [
            {
                title: 'Home',
                url: '/home',
                icon: 'home'
            }
        ];
        this.appName = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].appName;
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            document.title = _environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].appName;
        });
    };
    AppComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
        { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] }
    ]; };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _menubar_menubar_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./menubar/menubar.component */ "./src/app/menubar/menubar.component.ts");
/* harmony import */ var _auth_auth_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./auth/auth.module */ "./src/app/auth/auth.module.ts");
/* harmony import */ var _api_api_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./api/api.service */ "./src/app/api/api.service.ts");












var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
                _menubar_menubar_component__WEBPACK_IMPORTED_MODULE_9__["MenubarComponent"]
            ],
            entryComponents: [],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
                _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                _auth_auth_module__WEBPACK_IMPORTED_MODULE_10__["AuthModule"]
            ],
            providers: [
                _api_api_service__WEBPACK_IMPORTED_MODULE_11__["ApiService"],
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/auth/auth-login/auth-login.component.scss":
/*!***********************************************************!*\
  !*** ./src/app/auth/auth-login/auth-login.component.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvYXV0aC1sb2dpbi9hdXRoLWxvZ2luLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/auth/auth-login/auth-login.component.ts":
/*!*********************************************************!*\
  !*** ./src/app/auth/auth-login/auth-login.component.ts ***!
  \*********************************************************/
/*! exports provided: AuthLoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthLoginComponent", function() { return AuthLoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/auth.service */ "./src/app/auth/services/auth.service.ts");





var AuthLoginComponent = /** @class */ (function () {
    function AuthLoginComponent(formBuilder, auth, modal) {
        this.formBuilder = formBuilder;
        this.auth = auth;
        this.modal = modal;
    }
    AuthLoginComponent.prototype.ngOnInit = function () {
        this.loginForm = this.formBuilder.group({
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
            ]))
        });
    };
    AuthLoginComponent.prototype.onSubmit = function ($event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                $event.preventDefault();
                if (!this.loginForm.valid) {
                    return [2 /*return*/];
                }
                this.auth.login(this.loginForm.controls.email.value, this.loginForm.controls.password.value)
                    .then(function (user) {
                    _this.modal.dismiss();
                })
                    .catch(function (e) {
                    _this.error = e.statusText;
                    throw e;
                });
                return [2 /*return*/];
            });
        });
    };
    AuthLoginComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] }
    ]; };
    AuthLoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-auth-login',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./auth-login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-login/auth-login.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./auth-login.component.scss */ "./src/app/auth/auth-login/auth-login.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]])
    ], AuthLoginComponent);
    return AuthLoginComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-menu-button/auth-menu-button.component.scss":
/*!***********************************************************************!*\
  !*** ./src/app/auth/auth-menu-button/auth-menu-button.component.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (":host {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n          flex-direction: row;\n  -webkit-box-align: center;\n          align-items: center;\n  -webkit-box-pack: center;\n          justify-content: center;\n}\n\nion-avatar {\n  width: 35px;\n  height: 35px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXV0aC9hdXRoLW1lbnUtYnV0dG9uL0M6XFxVc2Vyc1xcVG9rYWFcXE9uZURyaXZlXFxEZXNrdG9wXFxBV1MtZGVwbG95bWVudFxcbmQwMDY3LWM0LWRlcGxveW1lbnQtcHJvY2Vzcy1wcm9qZWN0LXN0YXJ0ZXJcXHVkYWdyYW1cXHVkYWdyYW0tZnJvbnRlbmQvc3JjXFxhcHBcXGF1dGhcXGF1dGgtbWVudS1idXR0b25cXGF1dGgtbWVudS1idXR0b24uY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2F1dGgvYXV0aC1tZW51LWJ1dHRvbi9hdXRoLW1lbnUtYnV0dG9uLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0JBQUE7RUFBQSxhQUFBO0VBQ0EsOEJBQUE7RUFBQSw2QkFBQTtVQUFBLG1CQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9hdXRoL2F1dGgtbWVudS1idXR0b24vYXV0aC1tZW51LWJ1dHRvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn1cclxuXHJcbmlvbi1hdmF0YXIge1xyXG4gICAgd2lkdGg6IDM1cHg7XHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbn0iLCI6aG9zdCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG5pb24tYXZhdGFyIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogMzVweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/auth/auth-menu-button/auth-menu-button.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/auth/auth-menu-button/auth-menu-button.component.ts ***!
  \*********************************************************************/
/*! exports provided: AuthMenuButtonComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthMenuButtonComponent", function() { return AuthMenuButtonComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _auth_menu_user_auth_menu_user_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth-menu-user/auth-menu-user.component */ "./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.ts");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/auth.service */ "./src/app/auth/services/auth.service.ts");
/* harmony import */ var _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../auth-login/auth-login.component */ "./src/app/auth/auth-login/auth-login.component.ts");
/* harmony import */ var _auth_register_auth_register_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth-register/auth-register.component */ "./src/app/auth/auth-register/auth-register.component.ts");







var AuthMenuButtonComponent = /** @class */ (function () {
    function AuthMenuButtonComponent(auth, modalController) {
        this.auth = auth;
        this.modalController = modalController;
    }
    AuthMenuButtonComponent.prototype.presentmodal = function (ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _auth_menu_user_auth_menu_user_component__WEBPACK_IMPORTED_MODULE_3__["AuthMenuUserComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    AuthMenuButtonComponent.prototype.presentLogin = function (ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_5__["AuthLoginComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    AuthMenuButtonComponent.prototype.presentRegister = function (ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalController.create({
                            component: _auth_register_auth_register_component__WEBPACK_IMPORTED_MODULE_6__["AuthRegisterComponent"],
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    AuthMenuButtonComponent.prototype.logout = function () {
        this.auth.logout();
    };
    AuthMenuButtonComponent.prototype.ngOnInit = function () { };
    AuthMenuButtonComponent.ctorParameters = function () { return [
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    AuthMenuButtonComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-auth-menu-button',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./auth-menu-button.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-menu-button/auth-menu-button.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./auth-menu-button.component.scss */ "./src/app/auth/auth-menu-button/auth-menu-button.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], AuthMenuButtonComponent);
    return AuthMenuButtonComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.scss":
/*!************************************************************************************!*\
  !*** ./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.scss ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvYXV0aC1tZW51LWJ1dHRvbi9hdXRoLW1lbnUtdXNlci9hdXRoLW1lbnUtdXNlci5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.ts ***!
  \**********************************************************************************/
/*! exports provided: AuthMenuUserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthMenuUserComponent", function() { return AuthMenuUserComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var AuthMenuUserComponent = /** @class */ (function () {
    function AuthMenuUserComponent(modalCtrl) {
        this.modalCtrl = modalCtrl;
    }
    AuthMenuUserComponent.prototype.ngOnInit = function () { };
    AuthMenuUserComponent.prototype.dismissModal = function () {
        this.modalCtrl.dismiss();
    };
    AuthMenuUserComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
    ]; };
    AuthMenuUserComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-auth-menu-user',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./auth-menu-user.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./auth-menu-user.component.scss */ "./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]])
    ], AuthMenuUserComponent);
    return AuthMenuUserComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth-register/auth-register.component.scss":
/*!*****************************************************************!*\
  !*** ./src/app/auth/auth-register/auth-register.component.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2F1dGgvYXV0aC1yZWdpc3Rlci9hdXRoLXJlZ2lzdGVyLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/auth/auth-register/auth-register.component.ts":
/*!***************************************************************!*\
  !*** ./src/app/auth/auth-register/auth-register.component.ts ***!
  \***************************************************************/
/*! exports provided: AuthRegisterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthRegisterComponent", function() { return AuthRegisterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ "./src/app/auth/services/auth.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var AuthRegisterComponent = /** @class */ (function () {
    function AuthRegisterComponent(formBuilder, auth, modal) {
        this.formBuilder = formBuilder;
        this.auth = auth;
        this.modal = modal;
    }
    AuthRegisterComponent.prototype.ngOnInit = function () {
        this.registerForm = this.formBuilder.group({
            password_confirm: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required),
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
            ])),
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern('^[a-zA-Z0-9_.+-]+$')
            ]))
        }, { validators: this.passwordsMatch });
    };
    AuthRegisterComponent.prototype.onSubmit = function ($event) {
        var _this = this;
        $event.preventDefault();
        if (!this.registerForm.valid) {
            return;
        }
        var newuser = {
            email: this.registerForm.controls.email.value,
            name: this.registerForm.controls.name.value
        };
        this.auth.register(newuser, this.registerForm.controls.password.value)
            .then(function (user) {
            _this.modal.dismiss();
        })
            .catch(function (e) {
            _this.error = e.statusText;
            throw e;
        });
    };
    AuthRegisterComponent.prototype.passwordsMatch = function (group) {
        return group.controls.password.value === group.controls.password_confirm.value ? null : { passwordsMisMatch: true };
    };
    AuthRegisterComponent.ctorParameters = function () { return [
        { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
        { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
    ]; };
    AuthRegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-auth-register',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./auth-register.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/auth/auth-register/auth-register.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./auth-register.component.scss */ "./src/app/auth/auth-register/auth-register.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]])
    ], AuthRegisterComponent);
    return AuthRegisterComponent;
}());



/***/ }),

/***/ "./src/app/auth/auth.module.ts":
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/*! exports provided: AuthModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthModule", function() { return AuthModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _auth_menu_button_auth_menu_button_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth-menu-button/auth-menu-button.component */ "./src/app/auth/auth-menu-button/auth-menu-button.component.ts");
/* harmony import */ var _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth-login/auth-login.component */ "./src/app/auth/auth-login/auth-login.component.ts");
/* harmony import */ var _auth_register_auth_register_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./auth-register/auth-register.component */ "./src/app/auth/auth-register/auth-register.component.ts");
/* harmony import */ var _auth_menu_button_auth_menu_user_auth_menu_user_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./auth-menu-button/auth-menu-user/auth-menu-user.component */ "./src/app/auth/auth-menu-button/auth-menu-user/auth-menu-user.component.ts");
/* harmony import */ var _api_api_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../api/api.module */ "./src/app/api/api.module.ts");










var entryComponents = [_auth_menu_button_auth_menu_user_auth_menu_user_component__WEBPACK_IMPORTED_MODULE_8__["AuthMenuUserComponent"], _auth_menu_button_auth_menu_button_component__WEBPACK_IMPORTED_MODULE_5__["AuthMenuButtonComponent"], _auth_login_auth_login_component__WEBPACK_IMPORTED_MODULE_6__["AuthLoginComponent"], _auth_register_auth_register_component__WEBPACK_IMPORTED_MODULE_7__["AuthRegisterComponent"]];
var components = entryComponents.slice();
var AuthModule = /** @class */ (function () {
    function AuthModule() {
    }
    AuthModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _api_api_module__WEBPACK_IMPORTED_MODULE_9__["ApiModule"]
            ],
            entryComponents: entryComponents,
            declarations: components,
            exports: components,
            providers: []
        })
    ], AuthModule);
    return AuthModule;
}());



/***/ }),

/***/ "./src/app/auth/services/auth.service.ts":
/*!***********************************************!*\
  !*** ./src/app/auth/services/auth.service.ts ***!
  \***********************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var src_app_api_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/api/api.service */ "./src/app/api/api.service.ts");




var JWT_LOCALSTORE_KEY = 'jwt';
var USER_LOCALSTORE_KEY = 'user';
var AuthService = /** @class */ (function () {
    function AuthService(api) {
        this.api = api;
        this.currentUser$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](null);
        this.initToken();
    }
    AuthService.prototype.initToken = function () {
        var token = localStorage.getItem(JWT_LOCALSTORE_KEY);
        var user = JSON.parse(localStorage.getItem(USER_LOCALSTORE_KEY));
        if (token && user) {
            this.setTokenAndUser(token, user);
        }
    };
    AuthService.prototype.setTokenAndUser = function (token, user) {
        localStorage.setItem(JWT_LOCALSTORE_KEY, token);
        localStorage.setItem(USER_LOCALSTORE_KEY, JSON.stringify(user));
        this.api.setAuthToken(token);
        this.currentUser$.next(user);
    };
    AuthService.prototype.login = function (email, password) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                return [2 /*return*/, this.api.post('/users/auth/login', { email: email, password: password })
                        .then(function (res) {
                        _this.setTokenAndUser(res.token, res.user);
                        return res;
                    })
                        .catch(function (e) { throw e; })];
            });
        });
    };
    AuthService.prototype.logout = function () {
        this.setTokenAndUser(null, null);
        return true;
    };
    AuthService.prototype.register = function (user, password) {
        var _this = this;
        return this.api.post('/users/auth/', { email: user.email, password: password })
            .then(function (res) {
            _this.setTokenAndUser(res.token, res.user);
            return res;
        })
            .catch(function (e) { throw e; });
    };
    AuthService.ctorParameters = function () { return [
        { type: src_app_api_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] }
    ]; };
    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [src_app_api_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/menubar/menubar.component.scss":
/*!************************************************!*\
  !*** ./src/app/menubar/menubar.component.scss ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-title {\n  font-weight: bold;\n  font-family: \"Dancing Script\", cursive;\n  font-size: 180%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVudWJhci9DOlxcVXNlcnNcXFRva2FhXFxPbmVEcml2ZVxcRGVza3RvcFxcQVdTLWRlcGxveW1lbnRcXG5kMDA2Ny1jNC1kZXBsb3ltZW50LXByb2Nlc3MtcHJvamVjdC1zdGFydGVyXFx1ZGFncmFtXFx1ZGFncmFtLWZyb250ZW5kL3NyY1xcYXBwXFxtZW51YmFyXFxtZW51YmFyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9tZW51YmFyL21lbnViYXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtFQUNBLHNDQUFBO0VBQ0EsZUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvbWVudWJhci9tZW51YmFyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRpdGxlIHsgXHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGZvbnQtZmFtaWx5OiAnRGFuY2luZyBTY3JpcHQnLCBjdXJzaXZlO1xyXG4gICAgZm9udC1zaXplOiAxODAlO1xyXG4gIH0iLCJpb24tdGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZm9udC1mYW1pbHk6IFwiRGFuY2luZyBTY3JpcHRcIiwgY3Vyc2l2ZTtcbiAgZm9udC1zaXplOiAxODAlO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/menubar/menubar.component.ts":
/*!**********************************************!*\
  !*** ./src/app/menubar/menubar.component.ts ***!
  \**********************************************/
/*! exports provided: MenubarComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenubarComponent", function() { return MenubarComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");



var MenubarComponent = /** @class */ (function () {
    function MenubarComponent() {
        this.appName = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].appName;
    }
    MenubarComponent.prototype.ngOnInit = function () { };
    MenubarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-menubar',
            template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./menubar.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/menubar/menubar.component.html")).default,
            styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./menubar.component.scss */ "./src/app/menubar/menubar.component.scss")).default]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], MenubarComponent);
    return MenubarComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

var environment = {
    production: false,
    appName: 'Udagram',
    apiHost: 'http://localhost:3000/api/v0'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\Tokaa\OneDrive\Desktop\AWS-deployment\nd0067-c4-deployment-process-project-starter\udagram\udagram-frontend\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map